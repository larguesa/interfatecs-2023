a, b = map(str, input().split())
a = int(a)

for i in range(a):
    j = 0
    for k in range(26-i-1):
        print('.', end='')
    for j in range(i+1):
        if(b == 'maiusculas'):
            print(chr(65 + j), end='')
        else:
            print(chr(97 + j), end='')
    print()
# 65 maiusculo
# 97 minusculo