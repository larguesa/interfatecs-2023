
while(1):

    n = int(input())
    if(n == 0):
        break
    i = 1
    while (i * i <= n):
        print(i*i, end='')
        i+=1
        if(i*i <= n):
            print(' ', end='')
    print()
    