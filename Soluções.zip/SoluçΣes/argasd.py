ne, nb = map(int, input().split())
nd = int(input())
flag = 0
listab = [[0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
          [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
          [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
          [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
          [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
          [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
          [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
          [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
          [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
          [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],]

l = 0
m = 0
    
for b in range(nd):
    
    descarte = input()
    
    for i in range(ne * ne - ne):
        x, y, z = map(int, input().split())
        x -= 1
        y -= 1
        listab[x][y] += z
        
    print(f'Final dia {b+1}')
    
    flag = 0
    for i in range(10):
        for j in range(10):
            if listab[i][j] >= nb and listab[j][i] >= nb:
                flag = 1
                l = listab[i][j] // nb
                m = listab[j][i] // nb
                listab[i][j] -= nb*l
                listab[j][i] -= nb*m
                print(f'  Trocas entre {i+1}({l}v) e {j+1}({m}v)')
                
    if not flag:
        print('  Sem Trocas')
                
        
    