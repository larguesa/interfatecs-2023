x, y, b = map(int, input().split())

z, w = map(int, input().split())

k = 0
n = input()
for i in range(len(n)):
    if (i+1) > b:
        break
    l = n[i]
    if (l == 'C'):
        z-=1
        if(z < 1):
            k+=1
            z+=1
    if (l == 'B'):
        z+=1
        if(z > x):
            k+=1
            z-=1
    if (l == 'E'):
        w-=1
        if(w < 1):
            k+=1
            w+=1
    if (l == 'D'):
        w+=1
        if(w > y):
            k+=1
            w-=1
            
print(z, w, k)