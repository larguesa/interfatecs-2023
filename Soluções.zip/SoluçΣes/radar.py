n = int(input())

if(n >= 107):
    print(round(n + n * 0.07))
else:
    print(n + 7)